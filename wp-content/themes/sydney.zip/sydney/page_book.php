<?php
/*
Template Name: Temlate_book
*/
?>
<?php
get_header_for_book();
?>


    <div id="primary" class="content-area col-md-9">
        <main id="main" class="post-wrap" role="main">

        </main><!-- #main -->
    </div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer_for_book(); ?>